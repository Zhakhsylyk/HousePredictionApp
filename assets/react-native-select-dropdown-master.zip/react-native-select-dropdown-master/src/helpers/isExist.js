export default isExist = value => {
  if (value != undefined && value != null) {
    return true;
  }
  return false;
};
